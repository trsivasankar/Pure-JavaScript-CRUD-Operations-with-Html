// let url = "https://jsonplaceholder.typicode.com/posts";

// fetch(url).then((res) => {
//   res.json().then((data) => {
//     data = data.slice(0, 10);
//     if (data.length > 0) {
//       let temp = "";

//       data.forEach((element) => {
//         temp += "<tr>";
//         temp += "<td>" + element.userId + "</td>";
//         temp += "<td>" + element.id + "</td>";
//         temp += "<td>" + element.title + "</td>";
//         temp += "<td>" + element.body + "</td>" + "</tr>";
//       });

//       document.getElementById("datatable").innerHTML = temp;
//     }
//   });
// });

// document.addEventListener("click", function () {
//   var index,
//     table = document.getElementById("table");

//   for (var i = 0; i < table.rows.length; i++) {
//     table.rows[i].onclick = function () {
//       var c = confirm("do you want to delete this row");
//       if (c === true) {
//         index = this.rowIndex;
//         // table.deleteRow(index);
//         document.getElementById("userId").value = this.cells[0].innerHTML;
//       }
//     };
//   }
// });
var rindex;
function addRow() {
  var newuserId = document.getElementById("userId").value;
  var newid = document.getElementById("iddetails").value;
  var newTitle = document.getElementById("title").value;
  var newDesc = document.getElementById("desc").value;
  var table = document.getElementById("table");

  var newRow = table.insertRow(table.rows.length);

  if (
    isNaN(newuserId) === false &&
    isNaN(newid) === false &&
    isNaN(newTitle) === true &&
    isNaN(newDesc) === true
  ) {
    var cel1 = newRow.insertCell(0);
    var cel2 = newRow.insertCell(1);
    var cel3 = newRow.insertCell(2);
    var cel4 = newRow.insertCell(3);
    cel1.innerHTML = newuserId;
    cel2.innerHTML = newid;
    cel3.innerHTML = newTitle;
    cel4.innerHTML = newDesc;
  } else {
    alert("please enter correct values");
  }

  document.getElementById("userId").value = "";
  document.getElementById("iddetails").value = "";
  document.getElementById("title").value = "";
  document.getElementById("desc").value = "";

  selectedRowtoInput();
}

function selectedRowtoInput() {
  var table = document.getElementById("table");
  for (var i = 0; i < table.rows.length; i++) {
    table.rows[i].onclick = function () {
      rindex = this.rowIndex;
      // table.deleteRow(index);
      document.getElementById("userId").value = this.cells[0].innerHTML;
      document.getElementById("iddetails").value = this.cells[1].innerHTML;
      document.getElementById("title").value = this.cells[2].innerHTML;
      document.getElementById("desc").value = this.cells[3].innerHTML;
    };
  }
}
function editRow() {
  var newuserId = document.getElementById("userId").value;
  var newid = document.getElementById("iddetails").value;
  var newTitle = document.getElementById("title").value;
  var newDesc = document.getElementById("desc").value;
  var table = document.getElementById("table");
  table.rows[rindex].cells[0].innerHTML = newuserId;
  table.rows[rindex].cells[1].innerHTML = newid;
  table.rows[rindex].cells[2].innerHTML = newTitle;
  table.rows[rindex].cells[3].innerHTML = newDesc;
}

function removeSelectedRow() {
  table.deleteRow(rindex);
  // clear input text
  document.getElementById("userId").value = "";
  document.getElementById("iddetails").value = "";
  document.getElementById("title").value = "";
  document.getElementById("desc").value = "";
}
function saveData() {
  var dataDetails = [];

  var dataObj = {
    id: document.getElementById("userId").value,
    UserId: document.getElementById("userId").value,
    Title: document.getElementById("title").value,
    Description: document.getElementById("desc").value,
  };

  dataDetails.push(dataObj);
  addRow();

  var pre = document.querySelector("#msg pre");
  pre.textContent = JSON.stringify(dataDetails);
}
